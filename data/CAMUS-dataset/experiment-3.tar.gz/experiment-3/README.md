## Experiment 3: End-to-end network reconstruction on the CAMUS data set

Experiment 3 evaluates NetCS as part of an end-to-end semi-directed
level-1 phylogenetic network reconstruction pipeline and compares it
with NANUQ+ and CAMUS.

The data sets were originally simulated for the CAMUS study. Four
taxon-size conditions are included:

- `n50`
- `n100`
- `n150`
- `n200`

The original simulated networks contain 51, 101, 151, and 201 taxa,
respectively, including a single outgroup taxon. Each replicate contains
1000 estimated gene trees.

### Replicate filtering
Replicate networks containing degree-4 blobs were excluded because the
hybrid vertex is not identifiable for such blobs. After filtering, the
numbers of retained replicates are:

- `n50`: 47 replicates
- `n100`: 45 replicates
- `n150`: 43 replicates
- `n200`: 49 replicates

This filtering is based on the topology of the **true network**
and is independent of whether an individual inference method successfully
completed.

### Method failures and missing estimated networks

Not every inference method successfully completed for every retained
replicate.

If a method failed to finish or failed to produce a valid final network, that
estimated network is **not included in this deposit**.

Therefore, a retained replicate directory may contain outputs from only
a subset of the methods.

### Experiment 3 results summary

The file `experiment-3.csv` contains the processed error measurements
used for the Experiment 3 comparison.

Each row corresponds to one reconstruction method applied to one
retained CAMUS replicate. Replicates are identified by their taxon-size
condition and `network_id`, and the `method` column identifies the
reconstruction method.

To ensure a fair comparison across methods, the CSV contains only
replicates for which all methods included in a given model condition
produced a valid estimated network and could therefore be evaluated.

After this complete-case filtering, the numbers of replicates included
in `experiment-3.csv` are:

- 50 taxa: 44 replicates
- 100 taxa: 42 replicates
- 150 taxa: 40 replicates
- 200 taxa: 44 replicates

For the 50- and 100-taxon conditions, the comparison includes:

- `CAMUS`
- `NANQUPLUS-TOB-QMC-3f1a`
- `NET-CS-TOB-QMC-3f1a`

NANUQ+ was unable to complete the 150- and 200-taxon conditions because
runs exceeded either the available memory limit (256 GB) or wall-clock
limit (24 hours). Therefore, the fair comparison for these larger model
conditions includes only the methods that could be run successfully.

The experiment results are included in ```experiment-3.csv```.
The derived draft analysis figure is included in ```figure3-draft.pdf``` and ```figure4-draft.pdf```.
The final figure appearing in the paper may differ slightly in visual
presentation because it may be manually edited in Adobe Illustrator for
publication. Any such edits are only limited to cosmetic layout adjustments; the underlying data and numerical
results are unchanged.

### ASTRAL-IV trees and estimated networks

For each retained replicate, the directory contains the ASTRAL-IV base
tree and estimated networks produced by the reconstruction methods.

The primary end-to-end methods included in this deposit are:

- `CAMUS`
- `NANQUPLUS-TOB-QMC-3f1a`
- `NET-CS-TOB-QMC-3f1a`


```text
experiment-3/
├── n50/
│   ├── 00/
│   │   ├── CAMUS/
│   │   │   └── camus_n50_network_00.matched_extended_newick.nwk
│   │   ├── NANQUPLUS-TOB-QMC-3f1a/
│   │   │   └── NANQUPLUS-TOB-QMC-3f1a_n50_network_00.level1_network.nwk
│   │   ├── NET-CS-TOB-QMC-3f1a/
│   │   │   └── NET-CS-TOB-QMC-3f1a_n50_network_00.level1_network.nwk
│   │   └── astral4-rooted.tre
│   └── ...
├── n100/
├── n150/
├── n200/
└── experiment-3.csv
└── figure3-draft.pdf
└── figure4-draft.pdf




