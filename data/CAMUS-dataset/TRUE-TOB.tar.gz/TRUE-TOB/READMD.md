This directory contains the **true trees of blobs (TOBs)** derived from
the simulated CAMUS model networks.


## Directory structure

The files are organized by CAMUS taxon-size condition and replicate:

```text
TRUE-TOB/
├── n50/
│   ├── 00/
│   │   └── true_net.nwk.tob
│   ├── 01/
│   │   └── true_net.nwk.tob
│   ├── 02/
│   │   └── true_net.nwk.tob
│   └── ...
├── n100/
│   └── ...
├── n150/
│   └── ...
└── n200/
    └── ...