# Experiment 2: NetCS vs. NANUQ+ with the True Tree of Blobs

## Overview

Experiment 2 evaluates NetCS and NANUQ+ for level-1 blob reconstruction
when both methods are provided with the true tree of blobs (TOB).

The purpose of this experiment is to compare the two methods in terms of:

- hybrid detection accuracy,
- circular-order reconstruction accuracy,
- runtime, and
- peak memory usage.

Experiment 2 uses estimated gene trees and the true tree of blobs are orginally provided in [TOB-QMC-study](https://datadryad.org/dataset/doi:10.5061/dryad.cjsxksnnp)

## Data sets

The experiment contains three taxon-size conditions:

- `50_taxa`
- `100_taxa`
- `200_taxa`

For each taxon size, four branch-length scaling factors are considered:

- `ils_0.25`
- `ils_0.5`
- `ils_1.0`
- `ils_2.0`

These scaling factors control the amount of incomplete lineage sorting
(ILS). Smaller scaling factors correspond to shorter branches and
therefore higher levels of ILS.

There are 20 replicate networks for each taxon-size and branch-scaling
condition.

Each replicate was originally simulated with 1000 gene trees under the
network multispecies coalescent. In Experiment 2, estimated gene trees
are used instead of the true gene trees. Gene-tree estimation error
ranges approximately from 40% to 70% across the model conditions.

## Methods

The two methods evaluated are:

- `NET-CS-TRUE-TOB`
- `NANQUPLUS-TRUE-TOB`


## Directory structure

The directory is organized by taxon count, level, branch-scaling factor,
and reconstruction method.

For example:

```text
experiment-2/
├── 50_taxa/
│   └── level_1/
│       ├── ils_0.25/
│       │   ├── NANQUPLUS-TRUE-TOB/
│       │   └── NET-CS-TRUE-TOB/
│       ├── ils_0.5/
│       │   ├── NANQUPLUS-TRUE-TOB/
│       │   └── NET-CS-TRUE-TOB/
│       ├── ils_1.0/
│       │   ├── NANQUPLUS-TRUE-TOB/
│       │   └── NET-CS-TRUE-TOB/
│       └── ils_2.0/
│           ├── NANQUPLUS-TRUE-TOB/
│           └── NET-CS-TRUE-TOB/
├── 100_taxa/
│   └── level_1/
│       └── ...
├── 200_taxa/
│   └── level_1/
│       └── ...
└── experiment-2.csv