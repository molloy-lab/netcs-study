# Experiment 1: Effect of Gene-Tree Sample Size on NetCS Blob Reconstruction

## Overview

Experiment 1 evaluates the accuracy of NetCS for reconstructing individual
level-1 blobs when the true tree of blobs (TOB) is provided.

The experiment studies how reconstruction accuracy changes with:

- the number of taxa,
- the level of incomplete lineage sorting (ILS), and
- the number of true gene trees supplied to NetCS.

The primary quantities evaluated are:

- hybrid-block reconstruction error,
- circular-order reconstruction error measured using Kendall-tau
  distance,
- runtime, and
- peak memory usage.

---

## Data sets

The experiment contains three taxon-size conditions:

- `50_taxa`
- `100_taxa`
- `200_taxa`

Each taxon-size condition contains four branch-length scaling factors:

- `ils_0.25`
- `ils_0.5`
- `ils_1.0`
- `ils_2.0`

The branch scaling factor controls the amount of gene-tree discordance
caused by incomplete lineage sorting. Smaller scaling factors correspond
to shorter branches and higher levels of ILS.


20 level-1 replicate networks were simulated for each combination of
taxon count and branch scaling factor.

For each replicate network, 1000 true gene trees are orginally provided in [TOB-QMC-study](https://datadryad.org/dataset/doi:10.5061/dryad.cjsxksnnp). We then extract the first 100 and 500 gene trees from the orginal 1000 true gene trees.

---

## Number of gene trees

To investigate the effect of gene-tree sample size, NetCS was run using:

- 100 true gene trees,
- 500 true gene trees, and
- 1000 true gene trees.

These runs are stored in directories named:

```text
NET-CS-100-GT
NET-CS-500-GT
NET-CS-1000-GT
```

## Experiment 1 results:
The experiment results are included in ```experiment-1.csv```.
The derived draft analysis figure is included in ```figure2-draft.pdf```.
The final figure appearing in the paper may differ slightly in visual
presentation because it may be manually edited in Adobe Illustrator for
publication. Any such edits are only limited to cosmetic layout adjustments; the underlying data and numerical
results are unchanged.